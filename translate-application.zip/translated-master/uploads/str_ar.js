[{

    "general": {

        "welcome": "مرحبا",
        "eng_only_idiom": "هذا النص وهمي بالانجليزية",
        "carpool_input_require": "مطلوب إدخال هذا المكان"    
    }
}
        


]    

